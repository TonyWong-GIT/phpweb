<?php
define('FPDF_FONTPATH','font/');
require('invoice.php');

$pdf=new Invoice('P','mm','A4');
$pdf->Open();
$pdf->AddPage();
$pdf->SetMargins( 0.5, 0.5, 0.5 );
$pdf->addSociete( "MaSociete" ,
                  "MonAdresse\n" .
                  "75000 PARIS\n".
                  "R.C.S. PARIS B 000 000 007\n" .
                  "Capital : 18000 " . EURO );
$facture=1;
$pdf->addFacture($facture);
$pdf->addDate("03/12/2003");
$pdf->addClient("CL01");
$pdf->addPageNumber("1");
$pdf->addClientAdresse("Ste\nM. XXXX\n3�me �tage\n33, rue d'ailleurs\n75000 PARIS");

$pdf->addReglement("Ch�que � r�ception de facture");
$pdf->addEcheance("03/12/2003");
$pdf->addNumTVA("tva1");
$pdf->addReference("Devis ... du ....");
$cols=array("REFERENCE"    => 23,
            "DESIGNATION"  => 78,
            "QUANTITE"     => 22,
            "P.U. HT"      => 26,
            "MONTANT H.T." => 30,
            "TVA"          => 11 );
$pdf->addCols( $cols);
$cols=array("REFERENCE"    => "L",
            "DESIGNATION"  => "L",
            "QUANTITE"     => "C",
            "P.U. HT"      => "R",
            "MONTANT H.T." => "R",
            "TVA"          => "C" );
$pdf->addLineFormat($cols);

$y    = 108;
$line = array( "REFERENCE"    => "REF1",
               "DESIGNATION"  => "Carte M�re MSI 6378\n" .
                                 "Processeur AMD 1Ghz\n" .
                                 "128Mo SDRAM, 30 Go Disque, CD-ROM, Floppy, Carte vid�o",
               "QUANTITE"     => "1",
               "P.U. HT"      => "600.00",
               "MONTANT H.T." => "600.00",
               "TVA"          => "1" );
$prod[] = array("px_unit"=>600.00,"qte"=>1,"tva"=>"1");
$size = $pdf->addLine($y,$line);

$y   += $size ;
$line = array( "REFERENCE"    => "REF2",
               "DESIGNATION"  => "C�ble RS232",
               "QUANTITE"     => "1",
               "P.U. HT"      => "10.00",
               "MONTANT H.T." => "10.00",
               "TVA"          => "1" );
$prod[] = array("px_unit"=>10.00,"qte"=>1,"tva"=>"1");
$size = $pdf->addLine($y,$line);

$pdf->addRemarque("remarque");
$pdf->addCadreTVAs();
$pdf->addCadreEurosFrancs();
$pdf->addTVAs(array(),array("1"=>19.6),$prod);

$pdf->Output();
?>
