<?php
define('FPDF_FONTPATH','font/');
require('fpdf.php');

//==========================================================================
// PDF_Label
// (c) 2003 by LPA 
// lpasseb@numericable.fr
// Based on code by Steve Dillon (steved@mad.scientist.com)
//==========================================================================

class PDF_Label extends FPDF {

	// Private properties
	var $_Avery_Name  = '';        // Name of format
	var $_Margin_Left = 0;         // Left margin of labels
	var $_Margin_Top  = 0;         // Top margin of labels
	var $_X_Space     = 0;         // Horizontal space between 2 labels
	var $_Y_Space     = 0;         // Vertical space between 2 labels
	var $_X_Number    = 0;         // Number of labels horizontally
	var $_Y_Number    = 0;         // Number of labels vertically
	var $_Width       = 0;         // Width of label
	var $_Height      = 0;         // Height of label
	var $_Char_Size   = 10;        // Character size

	var $_COUNTX = 0;
	var $_COUNTY = 0;

	// List of all Avery formats
	var $Etiquettes_Avery = array (
		'L7163'=>array('name'=>'L7163', 'marginLeft'=>5, 'marginTop'=>15, 'NX'=>2, 'NY'=>7, 'SpaceX'=>25, 'SpaceY'=>0, 'width'=>99.1, 'height'=>38.1)
	);

	// Array matching character sizes and line heights
	var $Table_Hauteur_Chars = array(
		6=>2,
		8=>3,
		9=>4,
		10=>5,
		11=>6,
		12=>7
	);

	// Store parameters of the label format
	function _Set_Format($format) {
		$this->_Avery_Name  = $format['name'];
		$this->_Margin_Left = $format['marginLeft'];
		$this->_Margin_Top  = $format['marginTop'];
		$this->_X_Space     = $format['SpaceX'];
		$this->_Y_Space     = $format['SpaceY'];
		$this->_X_Number    = $format['NX'];
		$this->_Y_Number    = $format['NY'];
		$this->_Width       = $format['width'];
		$this->_Height      = $format['height'];
	}

	// Sets the character size
	// This changes the line height too
	function Set_Char_Size($pt) {
		if ($pt > 3) {
			$this->_Char_Size = $pt;
			$this->SetFont('Arial','',$this->_Char_Size);
		}
	}

	// Constructor
	function PDF_Label($format, $posX=0, $posY=0) {
		parent::FPDF();
		$this->SetMargins(0,0); 
		$this->Open(); 
		$this->Set_Char_Size(10);
		$this->AddPage(); 
		$this->SetAutoPageBreak(false); 

		// Start at the given label position
		$this->_COUNTX = $posX;
		$this->_COUNTY = $posY;
		if (is_array($format)) {
			// Custom format
			$this->_Set_Format($format);
		} else {
			// Avery format
			$this->_Set_Format($this->Etiquettes_Avery[$format]);
		}
	}

	// Print a label
	function Add_PDF_Label($texte) {
		if ($this->_COUNTY == $this->_Y_Number) {
			// End of column reached, we start a new one
			$this->_COUNTX++;
			$this->_COUNTY=0;
		}
		if ($this->_COUNTX == $this->_X_Number) {
			// Page full, we start a new one
			$this->_COUNTX=0;
			$this->_COUNTY=0;
			$this->AddPage();
		}

		$_PosX = $this->_Margin_Left+($this->_COUNTX*($this->_Width+$this->_X_Space));
		$_PosY = $this->_Margin_Top+($this->_COUNTY*($this->_Height+$this->_Y_Space));
		$this->SetXY($_PosX, $_PosY);
		$this->MultiCell($this->_Width, $this->Table_Hauteur_Chars[$this->_Char_Size], $texte);
		$this->_COUNTY++;
	}

}

/*-------------------------------------------------
To create the object, 2 possibilities:
either pass a custom format via an array
or use a built-in AVERY name
-------------------------------------------------*/

// Example of custom format; we start at the second column
//$pdf = new PDF_Label(array('name'=>'perso1', 'marginLeft'=>1, 'marginTop'=>1, 'NX'=>2, 'NY'=>7, 'SpaceX'=>0, 'SpaceY'=>0, 'width'=>99.1, 'height'=>'38.1'), 1, 0);
// Standard format
$pdf = new PDF_Label('L7163');

// Set the character size
$pdf->Set_Char_Size(8);
// Print labels
for($i=1;$i<=42;$i++)
	$pdf->Add_PDF_Label(sprintf("%s\n%s\n%s, %s, %s", "Laurent $i", 'av. fragonard', '06000', 'NICE', 'FRANCE'));

$pdf->Output();
?>
